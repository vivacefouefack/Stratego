#include <iostream>
#include "Game.h"
#include "Player.h"
#include "Position.h"
#include "Piece.h"
#include <vector>

using namespace std;

int main()
{


    return 0;
}
