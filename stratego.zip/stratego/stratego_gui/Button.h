/*#ifndef BUTTON_H
#define BUTTON_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainStratego; }
QT_END_NAMESPACE

class Button : public QMainWindow
{
    Q_OBJECT

public:
    Button(QWidget *parent = nullptr);


private:
    Ui::MainStratego *ui;

private slots:
    void blueOrigine1();
    void blueOrigine2();
    void blueOrigine3();
    void blueOrigine4();
    void blueOrigine5();
    void blueOrigine6();
    void blueOrigine7();
    void blueOrigine8();
    void blueOrigine9();
    void blueOrigine10();

    void blueDestination00();
    void blueDestination01();
    void blueDestination02();
    void blueDestination03();
    void blueDestination04();
    void blueDestination05();
    void blueDestination06();
    void blueDestination07();
    void blueDestination08();
    void blueDestination09();
    void blueDestination10();
};

#endif // BUTTON_H
*/
