#include "mainstratego.h"
#include "Button.h"
#include "ui_mainstratego.h"


QString permut="";


MainStratego::MainStratego(QWidget *parent): QMainWindow(parent), ui(new Ui::MainStratego)
{
    //std::vector<QPushButton> bluePieces{ui->piece1,ui->piece2};
    //std::vector<QPushButton> redPieces;
    //std::vector<QPushButton > waterPieces ;



    QList<QPushButton *>  listeinfos;
    QPushButton * p1=ui->piece1;
    QPushButton * p2=ui->piece2;
    QPushButton * p3=ui->piece3;
     listeinfos.append(p1);
     listeinfos.append(p2);
     listeinfos.append(p3);
     for(unsigned int i = 0; i <3; i++){
            //(*listeinfos[i]).setText("hh");
     }



    //bluePieces.push_back(*ui->piece2);
    //bluePieces.push_back(*ui->piece3);
    /*bluePieces.push_back(*ui->piece4);
    bluePieces.push_back(*ui->piece5);
    bluePieces.push_back(*ui->piece6);
    bluePieces.push_back(*ui->piece7);
    bluePieces.push_back(*ui->piece8);
    bluePieces.push_back(*ui->piece9);
    bluePieces.push_back(*ui->piece10);
    bluePieces.push_back(*ui->piece11);
    bluePieces.push_back(*ui->piece12);
    bluePieces.push_back(*ui->piece13);
    bluePieces.push_back(*ui->piece14);
    bluePieces.push_back(*ui->piece15);
    bluePieces.push_back(*ui->piece16);
    bluePieces.push_back(*ui->piece17);
    bluePieces.push_back(*ui->piece18);
    bluePieces.push_back(*ui->piece19);
    bluePieces.push_back(*ui->piece20);
    bluePieces.push_back(*ui->piece21);
    bluePieces.push_back(*ui->piece22);
    bluePieces.push_back(*ui->piece23);
    bluePieces.push_back(*ui->piece24);
    bluePieces.push_back(*ui->piece25);
    bluePieces.push_back(*ui->piece26);
    bluePieces.push_back(*ui->piece27);
    bluePieces.push_back(*ui->piece28);
    bluePieces.push_back(*ui->piece29);
    bluePieces.push_back(*ui->piece30);
    bluePieces.push_back(*ui->piece31);
    bluePieces.push_back(*ui->piece32);
    bluePieces.push_back(*ui->piece33);
    bluePieces.push_back(*ui->piece34);
    bluePieces.push_back(*ui->piece35);
    bluePieces.push_back(*ui->piece36);
    bluePieces.push_back(*ui->piece37);
    bluePieces.push_back(*ui->piece38);
    bluePieces.push_back(*ui->piece39);
    bluePieces.push_back(*ui->piece40);*/

    //bluePieces[0].setStyleSheet("QPushButton { background-color: blue; }");
    /*for(auto& vecteur : bluePieces){
         vecteur.setStyleSheet("QPushButton { background-color: blue; }");
     }*/

    /*for(unsigned int i = 0; i < bluePieces.size(); i++){
            bluePieces[i].setStyleSheet("QPushButton { background-color: blue; }");
    }*/


    ui->setupUi(this);
    ui->water42->setStyleSheet("QPushButton { background-color: skyblue; }");
    ui->water43->setStyleSheet("QPushButton { background-color: skyblue; }");
    ui->water46->setStyleSheet("QPushButton { background-color: skyblue; }");
    ui->water47->setStyleSheet("QPushButton { background-color: skyblue; }");
    ui->water52->setStyleSheet("QPushButton { background-color: skyblue; }");
    ui->water53->setStyleSheet("QPushButton { background-color: skyblue; }");
    ui->water56->setStyleSheet("QPushButton { background-color: skyblue; }");
    ui->water57->setStyleSheet("QPushButton { background-color: skyblue; }");


    ui->water42->setDisabled(true);
    ui->water43->setDisabled(true);
    ui->water46->setDisabled(true);
    ui->water47->setDisabled(true);
    ui->water52->setDisabled(true);
    ui->water53->setDisabled(true);
    ui->water56->setDisabled(true);
    ui->water57->setDisabled(true);


    std::vector<string> bluePieces{"10","9","D","6","6 ","7 ","7 ","7 ","8"," 8","1 ","5"," 4 ","4 ","6 ","6 ","4"," 4"," 5"," 5",
                "2"," 2"," 2"," 3 ","3"," 3"," 3"," 2"," 2"," 2","B"," B"," B ","2"," 3 ","5"," 2 ","B ","B ","B"};

    for(unsigned int i = 0; i <=39; i++){
            ui->redPieceGrid->itemAt(i)->widget()->setStyleSheet("QPushButton { background-color: red; }");

            ui->redPieceGrid->itemAt(i)->widget()->setDisabled(true);
    }



    for(unsigned int i = 0; i <=39; i++){
            ui->bluePieceGrid->itemAt(i)->widget()->setStyleSheet("QPushButton { background-color: blue; }");

    }






   /* for(auto& vecteur : bluePieces){
        //vecteur.setStyleSheet("QPushButton { background-color: blue; }");
    }*/
    connect(ui->piece1, &QPushButton::clicked, this, &MainStratego::blueOrigine1);
    connect(ui->piece2, &QPushButton::clicked, this, &MainStratego::blueOrigine2);
    connect(ui->piece3, &QPushButton::clicked, this, &MainStratego::blueOrigine3);
    connect(ui->piece4, &QPushButton::clicked, this, &MainStratego::blueOrigine4);
    connect(ui->piece5, &QPushButton::clicked, this, &MainStratego::blueOrigine5);
    connect(ui->piece6, &QPushButton::clicked, this, &MainStratego::blueOrigine6);
    connect(ui->piece7, &QPushButton::clicked, this, &MainStratego::blueOrigine7);
    connect(ui->piece8, &QPushButton::clicked, this, &MainStratego::blueOrigine8);
    connect(ui->piece9, &QPushButton::clicked, this, &MainStratego::blueOrigine9);
    connect(ui->piece10, &QPushButton::clicked, this, &MainStratego::blueOrigine10);
    connect(ui->piece11, &QPushButton::clicked, this, &MainStratego::blueOrigine11);
    connect(ui->piece12, &QPushButton::clicked, this, &MainStratego::blueOrigine12);
    connect(ui->piece13, &QPushButton::clicked, this, &MainStratego::blueOrigine13);
    connect(ui->piece14, &QPushButton::clicked, this, &MainStratego::blueOrigine14);
    connect(ui->piece15, &QPushButton::clicked, this, &MainStratego::blueOrigine15);
    connect(ui->piece16, &QPushButton::clicked, this, &MainStratego::blueOrigine16);
    connect(ui->piece17, &QPushButton::clicked, this, &MainStratego::blueOrigine17);
    connect(ui->piece18, &QPushButton::clicked, this, &MainStratego::blueOrigine18);
    connect(ui->piece19, &QPushButton::clicked, this, &MainStratego::blueOrigine19);
    connect(ui->piece20, &QPushButton::clicked, this, &MainStratego::blueOrigine20);
    connect(ui->piece21, &QPushButton::clicked, this, &MainStratego::blueOrigine21);
    connect(ui->piece22, &QPushButton::clicked, this, &MainStratego::blueOrigine22);
    connect(ui->piece23, &QPushButton::clicked, this, &MainStratego::blueOrigine23);
    connect(ui->piece24, &QPushButton::clicked, this, &MainStratego::blueOrigine24);
    connect(ui->piece25, &QPushButton::clicked, this, &MainStratego::blueOrigine25);
    connect(ui->piece26, &QPushButton::clicked, this, &MainStratego::blueOrigine26);
    connect(ui->piece27, &QPushButton::clicked, this, &MainStratego::blueOrigine27);
    connect(ui->piece28, &QPushButton::clicked, this, &MainStratego::blueOrigine28);
    connect(ui->piece29, &QPushButton::clicked, this, &MainStratego::blueOrigine29);
    connect(ui->piece30, &QPushButton::clicked, this, &MainStratego::blueOrigine30);
    connect(ui->piece31, &QPushButton::clicked, this, &MainStratego::blueOrigine31);
    connect(ui->piece32, &QPushButton::clicked, this, &MainStratego::blueOrigine32);
    connect(ui->piece33, &QPushButton::clicked, this, &MainStratego::blueOrigine33);
    connect(ui->piece34, &QPushButton::clicked, this, &MainStratego::blueOrigine34);
    connect(ui->piece35, &QPushButton::clicked, this, &MainStratego::blueOrigine35);
    connect(ui->piece36, &QPushButton::clicked, this, &MainStratego::blueOrigine36);
    connect(ui->piece37, &QPushButton::clicked, this, &MainStratego::blueOrigine37);
    connect(ui->piece38, &QPushButton::clicked, this, &MainStratego::blueOrigine38);
    connect(ui->piece39, &QPushButton::clicked, this, &MainStratego::blueOrigine39);
    connect(ui->piece40, &QPushButton::clicked, this, &MainStratego::blueOrigine40);


    connect(ui->pos00, &QPushButton::clicked, this, &MainStratego::blueDestination00);
    connect(ui->pos01, &QPushButton::clicked, this, &MainStratego::blueDestination01);
    connect(ui->pos02, &QPushButton::clicked, this, &MainStratego::blueDestination02);
    connect(ui->pos03, &QPushButton::clicked, this, &MainStratego::blueDestination03);
    connect(ui->pos04, &QPushButton::clicked, this, &MainStratego::blueDestination04);
    connect(ui->pos05, &QPushButton::clicked, this, &MainStratego::blueDestination05);
    connect(ui->pos06, &QPushButton::clicked, this, &MainStratego::blueDestination06);
    connect(ui->pos07, &QPushButton::clicked, this, &MainStratego::blueDestination07);
    connect(ui->pos08, &QPushButton::clicked, this, &MainStratego::blueDestination08);
    connect(ui->pos09, &QPushButton::clicked, this, &MainStratego::blueDestination09);
    connect(ui->pos10, &QPushButton::clicked, this, &MainStratego::blueDestination10);
    connect(ui->pos11, &QPushButton::clicked, this, &MainStratego::blueDestination11);
    connect(ui->pos22, &QPushButton::clicked, this, &MainStratego::blueDestination12);
    connect(ui->pos13, &QPushButton::clicked, this, &MainStratego::blueDestination13);
    connect(ui->pos14, &QPushButton::clicked, this, &MainStratego::blueDestination14);
    connect(ui->pos15, &QPushButton::clicked, this, &MainStratego::blueDestination15);
    connect(ui->pos16, &QPushButton::clicked, this, &MainStratego::blueDestination16);
    connect(ui->pos17, &QPushButton::clicked, this, &MainStratego::blueDestination17);
    connect(ui->pos18, &QPushButton::clicked, this, &MainStratego::blueDestination18);
    connect(ui->pos19, &QPushButton::clicked, this, &MainStratego::blueDestination19);
    connect(ui->pos20, &QPushButton::clicked, this, &MainStratego::blueDestination20);
    connect(ui->pos21, &QPushButton::clicked, this, &MainStratego::blueDestination21);
    connect(ui->pos22, &QPushButton::clicked, this, &MainStratego::blueDestination22);
    connect(ui->pos23, &QPushButton::clicked, this, &MainStratego::blueDestination23);
    connect(ui->pos24, &QPushButton::clicked, this, &MainStratego::blueDestination24);
    connect(ui->pos25, &QPushButton::clicked, this, &MainStratego::blueDestination25);
    connect(ui->pos26, &QPushButton::clicked, this, &MainStratego::blueDestination26);
    connect(ui->pos27, &QPushButton::clicked, this, &MainStratego::blueDestination27);
    connect(ui->pos28, &QPushButton::clicked, this, &MainStratego::blueDestination28);
    connect(ui->pos29, &QPushButton::clicked, this, &MainStratego::blueDestination29);
    connect(ui->pos30, &QPushButton::clicked, this, &MainStratego::blueDestination30);
    connect(ui->pos31, &QPushButton::clicked, this, &MainStratego::blueDestination31);
    connect(ui->pos32, &QPushButton::clicked, this, &MainStratego::blueDestination32);
    connect(ui->pos33, &QPushButton::clicked, this, &MainStratego::blueDestination33);
    connect(ui->pos34, &QPushButton::clicked, this, &MainStratego::blueDestination34);
    connect(ui->pos35, &QPushButton::clicked, this, &MainStratego::blueDestination35);
    connect(ui->pos36, &QPushButton::clicked, this, &MainStratego::blueDestination36);
    connect(ui->pos37, &QPushButton::clicked, this, &MainStratego::blueDestination37);
    connect(ui->pos38, &QPushButton::clicked, this, &MainStratego::blueDestination38);
    connect(ui->pos39, &QPushButton::clicked, this, &MainStratego::blueDestination39);










}

void MainStratego::calcul(){
    if(permut.size()==0){
        permut=ui->piece10->text();
        ui->piece10->setText("");
    }
}

void MainStratego::calcul1(){
    if(permut.size()!=0 && ui->pos11->text().size()==0){
        ui->pos11->setText(permut);
        permut="";
    }
}


void MainStratego::blueOrigine1(){
    if(permut.size()==0){
        permut=ui->piece1->text();
        ui->piece1->setText("");
    }
}
void MainStratego::blueOrigine2(){
    if(permut.size()==0){
        permut=ui->piece2->text();
        ui->piece2->setText("");
    }
}
void MainStratego::blueOrigine3(){
    if(permut.size()==0){
        permut=ui->piece3->text();
        ui->piece3->setText("");
    }
}
void MainStratego::blueOrigine4(){
    if(permut.size()==0){
        permut=ui->piece4->text();
        ui->piece4->setText("");
    }
}
void MainStratego::blueOrigine5(){
    if(permut.size()==0){
        permut=ui->piece5->text();
        ui->piece5->setText("");
    }
}
void MainStratego::blueOrigine6(){
    if(permut.size()==0){
        permut=ui->piece6->text();
        ui->piece6->setText("");
    }
}
void MainStratego::blueOrigine7(){
    if(permut.size()==0){
        permut=ui->piece7->text();
        ui->piece7->setText("");
    }
}
void MainStratego::blueOrigine8(){
    if(permut.size()==0){
        permut=ui->piece8->text();
        ui->piece8->setText("");
    }
}
void MainStratego::blueOrigine9(){
    if(permut.size()==0){
        permut=ui->piece9->text();
        ui->piece9->setText("");
    }
}
void MainStratego::blueOrigine10(){
    if(permut.size()==0){
        permut=ui->piece10->text();
        ui->piece10->setText("");
    }
}
void MainStratego::blueOrigine11(){
    if(permut.size()==0){
        permut=ui->piece11->text();
        ui->piece11->setText("");
    }
}
void MainStratego::blueOrigine12(){
    if(permut.size()==0){
        permut=ui->piece12->text();
        ui->piece12->setText("");
    }
}
void MainStratego::blueOrigine13(){
    if(permut.size()==0){
        permut=ui->piece13->text();
        ui->piece13->setText("");
    }
}
void MainStratego::blueOrigine14(){
    if(permut.size()==0){
        permut=ui->piece14->text();
        ui->piece14->setText("");
    }
}
void MainStratego::blueOrigine15(){
    if(permut.size()==0){
        permut=ui->piece15->text();
        ui->piece15->setText("");
    }
}
void MainStratego::blueOrigine16(){
    if(permut.size()==0){
        permut=ui->piece16->text();
        ui->piece16->setText("");
    }
}
void MainStratego::blueOrigine17(){
    if(permut.size()==0){
        permut=ui->piece17->text();
        ui->piece17->setText("");
    }
}
void MainStratego::blueOrigine18(){
    if(permut.size()==0){
        permut=ui->piece18->text();
        ui->piece18->setText("");
    }
}
void MainStratego::blueOrigine19(){
    if(permut.size()==0){
        permut=ui->piece19->text();
        ui->piece19->setText("");
    }
}
void MainStratego::blueOrigine20(){
    if(permut.size()==0){
        permut=ui->piece20->text();
        ui->piece20->setText("");
    }
}
void MainStratego::blueOrigine21(){
    if(permut.size()==0){
        permut=ui->piece21->text();
        ui->piece21->setText("");
    }
}
void MainStratego::blueOrigine22(){
    if(permut.size()==0){
        permut=ui->piece22->text();
        ui->piece22->setText("");
    }
}
void MainStratego::blueOrigine23(){
    if(permut.size()==0){
        permut=ui->piece23->text();
        ui->piece23->setText("");
    }
}
void MainStratego::blueOrigine24(){
    if(permut.size()==0){
        permut=ui->piece24->text();
        ui->piece24->setText("");
    }
}
void MainStratego::blueOrigine25(){
    if(permut.size()==0){
        permut=ui->piece25->text();
        ui->piece25->setText("");
    }
}
void MainStratego::blueOrigine26(){
    if(permut.size()==0){
        permut=ui->piece26->text();
        ui->piece26->setText("");
    }
}
void MainStratego::blueOrigine27(){
    if(permut.size()==0){
        permut=ui->piece27->text();
        ui->piece27->setText("");
    }
}
void MainStratego::blueOrigine28(){
    if(permut.size()==0){
        permut=ui->piece28->text();
        ui->piece28->setText("");
    }
}
void MainStratego::blueOrigine29(){
    if(permut.size()==0){
        permut=ui->piece29->text();
        ui->piece29->setText("");
    }
}
void MainStratego::blueOrigine30(){
    if(permut.size()==0){
        permut=ui->piece30->text();
        ui->piece30->setText("");
    }
}
void MainStratego::blueOrigine31(){
    if(permut.size()==0){
        permut=ui->piece31->text();
        ui->piece31->setText("");
    }
}
void MainStratego::blueOrigine32(){
    if(permut.size()==0){
        permut=ui->piece32->text();
        ui->piece32->setText("");
    }
}
void MainStratego::blueOrigine33(){
    if(permut.size()==0){
        permut=ui->piece33->text();
        ui->piece33->setText("");
    }
}
void MainStratego::blueOrigine34(){
    if(permut.size()==0){
        permut=ui->piece34->text();
        ui->piece34->setText("");
    }
}
void MainStratego::blueOrigine35(){
    if(permut.size()==0){
        permut=ui->piece35->text();
        ui->piece35->setText("");
    }
}
void MainStratego::blueOrigine36(){
    if(permut.size()==0){
        permut=ui->piece36->text();
        ui->piece36->setText("");
    }
}
void MainStratego::blueOrigine37(){
    if(permut.size()==0){
        permut=ui->piece37->text();
        ui->piece37->setText("");
    }
}
void MainStratego::blueOrigine38(){
    if(permut.size()==0){
        permut=ui->piece38->text();
        ui->piece38->setText("");
    }
}
void MainStratego::blueOrigine39(){
    if(permut.size()==0){
        permut=ui->piece39->text();
        ui->piece39->setText("");
    }
}
void MainStratego::blueOrigine40(){
    if(permut.size()==0){
        permut=ui->piece40->text();
        ui->piece40->setText("");
    }
}












void MainStratego::blueDestination00(){
    if(permut.size()!=0 && ui->pos00->text().size()==0){
        ui->pos00->setText(permut);
        ui->pos00->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination01(){
    if(permut.size()!=0 && ui->pos01->text().size()==0){
        ui->pos01->setText(permut);
         ui->pos01->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination02(){
    if(permut.size()!=0 && ui->pos02->text().size()==0){
        ui->pos02->setText(permut);
         ui->pos02->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination03(){
    if(permut.size()!=0 && ui->pos03->text().size()==0){
        ui->pos03->setText(permut);
         ui->pos03->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination04(){
    if(permut.size()!=0 && ui->pos04->text().size()==0){
        ui->pos04->setText(permut);
         ui->pos04->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination05(){
    if(permut.size()!=0 && ui->pos05->text().size()==0){
        ui->pos05->setText(permut);
         ui->pos05->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination06(){
    if(permut.size()!=0 && ui->pos06->text().size()==0){
        ui->pos06->setText(permut);
         ui->pos06->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination07(){
    if(permut.size()!=0 && ui->pos07->text().size()==0){
        ui->pos07->setText(permut);
         ui->pos07->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination08(){
    if(permut.size()!=0 && ui->pos08->text().size()==0){
        ui->pos08->setText(permut);
         ui->pos08->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination09(){
    if(permut.size()!=0 && ui->pos09->text().size()==0){
        ui->pos09->setText(permut);
         ui->pos09->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}

void MainStratego::blueDestination10(){
    if(permut.size()!=0 && ui->pos10->text().size()==0){
        ui->pos10->setText(permut);
        ui->pos10->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination11(){
    if(permut.size()!=0 && ui->pos11->text().size()==0){
        ui->pos11->setText(permut);
        ui->pos11->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination12(){
    if(permut.size()!=0 && ui->pos12->text().size()==0){
        ui->pos12->setText(permut);
        ui->pos12->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination13(){
    if(permut.size()!=0 && ui->pos13->text().size()==0){
        ui->pos13->setText(permut);
        ui->pos13->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination14(){
    if(permut.size()!=0 && ui->pos14->text().size()==0){
        ui->pos14->setText(permut);
        ui->pos14->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination15(){
    if(permut.size()!=0 && ui->pos15->text().size()==0){
        ui->pos15->setText(permut);
        ui->pos15->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination16(){
    if(permut.size()!=0 && ui->pos16->text().size()==0){
        ui->pos16->setText(permut);
        ui->pos16->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination17(){
    if(permut.size()!=0 && ui->pos17->text().size()==0){
        ui->pos17->setText(permut);
        ui->pos17->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination18(){
    if(permut.size()!=0 && ui->pos18->text().size()==0){
        ui->pos18->setText(permut);
        ui->pos18->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}

void MainStratego::blueDestination19(){
    if(permut.size()!=0 && ui->pos19->text().size()==0){
        ui->pos19->setText(permut);
        ui->pos19->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination20(){
    if(permut.size()!=0 && ui->pos20->text().size()==0){
        ui->pos20->setText(permut);
        ui->pos20->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination21(){
    if(permut.size()!=0 && ui->pos21->text().size()==0){
        ui->pos21->setText(permut);
        ui->pos21->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination22(){
    if(permut.size()!=0 && ui->pos22->text().size()==0){
        ui->pos22->setText(permut);
        ui->pos22->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination23(){
    if(permut.size()!=0 && ui->pos23->text().size()==0){
        ui->pos23->setText(permut);
        ui->pos23->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination24(){
    if(permut.size()!=0 && ui->pos24->text().size()==0){
        ui->pos24->setText(permut);
        ui->pos24->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination25(){
    if(permut.size()!=0 && ui->pos25->text().size()==0){
        ui->pos25->setText(permut);
        ui->pos25->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination26(){
    if(permut.size()!=0 && ui->pos26->text().size()==0){
        ui->pos26->setText(permut);
        ui->pos26->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination27(){
    if(permut.size()!=0 && ui->pos27->text().size()==0){
        ui->pos27->setText(permut);
        ui->pos27->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination28(){
    if(permut.size()!=0 && ui->pos28->text().size()==0){
        ui->pos28->setText(permut);
        ui->pos28->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination29(){
    if(permut.size()!=0 && ui->pos29->text().size()==0){
        ui->pos29->setText(permut);
        ui->pos29->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination30(){
    if(permut.size()!=0 && ui->pos30->text().size()==0){
        ui->pos30->setText(permut);
        ui->pos30->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination31(){
    if(permut.size()!=0 && ui->pos31->text().size()==0){
        ui->pos31->setText(permut);
        ui->pos31->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination32(){
    if(permut.size()!=0 && ui->pos32->text().size()==0){
        ui->pos32->setText(permut);
        ui->pos32->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination33(){
    if(permut.size()!=0 && ui->pos33->text().size()==0){
        ui->pos33->setText(permut);
        ui->pos33->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination34(){
    if(permut.size()!=0 && ui->pos34->text().size()==0){
        ui->pos34->setText(permut);
        ui->pos34->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination35(){
    if(permut.size()!=0 && ui->pos35->text().size()==0){
        ui->pos35->setText(permut);
        ui->pos35->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination36(){
    if(permut.size()!=0 && ui->pos36->text().size()==0){
        ui->pos36->setText(permut);
        ui->pos36->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination37(){
    if(permut.size()!=0 && ui->pos37->text().size()==0){
        ui->pos37->setText(permut);
        ui->pos37->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination38(){
    if(permut.size()!=0 && ui->pos38->text().size()==0){
        ui->pos38->setText(permut);
        ui->pos38->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination39(){
    if(permut.size()!=0 && ui->pos39->text().size()==0){
        ui->pos39->setText(permut);
        ui->pos39->setStyleSheet("QPushButton { background-color: green; }");
        permut="";
    }
}
void MainStratego::blueDestination40(){

}

MainStratego::~MainStratego()
{
    delete ui;
}

