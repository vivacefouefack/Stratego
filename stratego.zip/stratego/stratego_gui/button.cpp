/*#include "Button.h"
#include "ui_mainstratego.h"


QString permut="";
Button::Button(QWidget *parent): QMainWindow(parent), ui(new Ui::MainStratego)
{


    connect(ui->piece1, &QPushButton::clicked, this, &Button::blueOrigine1);
    connect(ui->piece2, &QPushButton::clicked, this, &Button::blueOrigine2);
    connect(ui->piece3, &QPushButton::clicked, this, &Button::blueOrigine3);
    connect(ui->piece4, &QPushButton::clicked, this, &Button::blueOrigine4);
    connect(ui->piece5, &QPushButton::clicked, this, &Button::blueOrigine5);
    connect(ui->piece6, &QPushButton::clicked, this, &Button::blueOrigine6);
    connect(ui->piece7, &QPushButton::clicked, this, &Button::blueOrigine7);
    connect(ui->piece8, &QPushButton::clicked, this, &Button::blueOrigine8);
    connect(ui->piece9, &QPushButton::clicked, this, &Button::blueOrigine9);
    connect(ui->piece10, &QPushButton::clicked, this, &Button::blueOrigine10);
}


void Button::blueOrigine1(){
    if(permut.size()==0){
        permut=ui->piece1->text();
        ui->piece1->setText("");
    }
}
void Button::blueOrigine2(){
    if(permut.size()==0){
        permut=ui->piece2->text();
        ui->piece2->setText("");
    }
}
void Button::blueOrigine3(){
    if(permut.size()==0){
        permut=ui->piece3->text();
        ui->piece3->setText("");
    }
}
void Button::blueOrigine4(){
    if(permut.size()==0){
        permut=ui->piece4->text();
        ui->piece4->setText("");
    }
}
void Button::blueOrigine5(){
    if(permut.size()==0){
        permut=ui->piece5->text();
        ui->piece5->setText("");
    }
}
void Button::blueOrigine6(){
    if(permut.size()==0){
        permut=ui->piece6->text();
        ui->piece6->setText("");
    }
}
void Button::blueOrigine7(){
    if(permut.size()==0){
        permut=ui->piece7->text();
        ui->piece7->setText("");
    }
}
void Button::blueOrigine8(){
    if(permut.size()==0){
        permut=ui->piece8->text();
        ui->piece8->setText("");
    }
}
void Button::blueOrigine9(){
    if(permut.size()==0){
        permut=ui->piece9->text();
        ui->piece9->setText("");
    }
}
void Button::blueOrigine10(){
    if(permut.size()==0){
        permut=ui->piece10->text();
        ui->piece10->setText("");
    }
}*/
