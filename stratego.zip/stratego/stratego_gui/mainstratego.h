#ifndef MAINSTRATEGO_H
#define MAINSTRATEGO_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainStratego; }
QT_END_NAMESPACE
//#include "../controller/Controller.h"
//#include "../model/Piece.h"
//#include "../model/Player.h"
#include <vector>


using namespace std;

class MainStratego : public QMainWindow
{
    Q_OBJECT

public:
    MainStratego(QWidget *parent = nullptr);
    ~MainStratego();
    //void initialize();


private:
    Ui::MainStratego *ui;
    /*vector<Piece> *playerOne;

    vector<Piece>playerTwo;

    Player redPlayer;
    Player bluePlayer;*/

private slots:
    void calcul();
    void calcul1();

    void blueOrigine1();
    void blueOrigine2();
    void blueOrigine3();
    void blueOrigine4();
    void blueOrigine5();
    void blueOrigine6();
    void blueOrigine7();
    void blueOrigine8();
    void blueOrigine9();
    void blueOrigine10();
    void blueOrigine11();
    void blueOrigine12();
    void blueOrigine13();
    void blueOrigine14();
    void blueOrigine15();
    void blueOrigine16();
    void blueOrigine17();
    void blueOrigine18();
    void blueOrigine19();
    void blueOrigine20();
    void blueOrigine21();
    void blueOrigine22();
    void blueOrigine23();
    void blueOrigine24();
    void blueOrigine25();
    void blueOrigine26();
    void blueOrigine27();
    void blueOrigine28();
    void blueOrigine29();
    void blueOrigine30();
    void blueOrigine31();
    void blueOrigine32();
    void blueOrigine33();
    void blueOrigine34();
    void blueOrigine35();
    void blueOrigine36();
    void blueOrigine37();
    void blueOrigine38();
    void blueOrigine39();
    void blueOrigine40();




    void blueDestination00();
    void blueDestination01();
    void blueDestination02();
    void blueDestination03();
    void blueDestination04();
    void blueDestination05();
    void blueDestination06();
    void blueDestination07();
    void blueDestination08();
    void blueDestination09();
    void blueDestination10();
    void blueDestination11();
    void blueDestination12();
    void blueDestination13();
    void blueDestination14();
    void blueDestination15();
    void blueDestination16();
    void blueDestination17();
    void blueDestination18();
    void blueDestination19();
    void blueDestination20();
    void blueDestination21();
    void blueDestination22();
    void blueDestination23();
    void blueDestination24();
    void blueDestination25();
    void blueDestination26();
    void blueDestination27();
    void blueDestination28();
    void blueDestination29();
    void blueDestination30();
    void blueDestination31();
    void blueDestination32();
    void blueDestination33();
    void blueDestination34();
    void blueDestination35();
    void blueDestination36();
    void blueDestination37();
    void blueDestination38();
    void blueDestination39();
    void blueDestination40();
};
/*
void MainStratego::initialize(){
    Piece piece1(Position(1,2),"5");
    Piece piece2(Position(2,5),"2");
    Piece piece3(Position(6,7),"1");
    Piece piece4(Position(8,9),"8");
    Piece bombe(Position(8,2),"B");
    Piece bombe1(Position(2,4),"B");
    Piece drapeau(Position(9,1),"D");

    playerOne->push_back(piece1);
    playerOne->push_back(piece2);
    playerOne->push_back(piece3);
    playerOne->push_back(piece4);
    playerOne->push_back(bombe);
    playerOne->push_back(bombe1);
    playerOne->push_back(drapeau);


}*/

#endif // MAINSTRATEGO_H
